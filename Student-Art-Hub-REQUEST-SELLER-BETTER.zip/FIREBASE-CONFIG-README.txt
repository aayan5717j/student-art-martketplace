Firebase config synced from the current Firebase Web App (studentart marketplace).

If login still shows auth/api-key-not-valid on preview.hcodx.com, the code config is not the problem: check the API key in Google Cloud Console > APIs & Services > Credentials. A restricted/deleted/mismatched key can produce this error. Firebase documentation: https://firebase.google.com/docs/projects/api-keys
